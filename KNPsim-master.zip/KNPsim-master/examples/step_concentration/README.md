## Step concentration
This folder contains script used in Application 1 in the paper. To run all
simulations in Application 1, run `run_application_1.sh`.
