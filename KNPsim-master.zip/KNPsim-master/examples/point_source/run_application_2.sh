python knp_point_source.py
