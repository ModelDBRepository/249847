## Running the hay model examples
# Prerequisites
In order to run this example, you will first need to either:
1. Install NEURON with the NEURON python interface. Then type the following
  into the terminal (starting from the location of this file):
  ```
  cd neuron_model
  nrnivmodl
  sh run_neuron_model_full.sh
  ```
  Note that this will take hours to days depending on your system.
2. Download the NEURON simulation data by entering
  ```
  wget TODO
  ```
